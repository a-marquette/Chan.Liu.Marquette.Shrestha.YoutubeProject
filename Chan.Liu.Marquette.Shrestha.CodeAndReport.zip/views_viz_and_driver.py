'''
DS 2000
Elise Chan, Ruoxi (Selina) Liu, Alyssa Marquette, Carrline Shrestha
Project
'''
from view_analysis import calc_trend_over_control
from view_analysis import remove_outliers
from view_analysis import view_analysis
from views import calculate_average
from numpy import percentile
import turtle

XMINL = -250
XMAXL = -50
YMIN = -200
YMAX = 200
XMINR = 50
XMAXR = 250

def draw_axes(xmin,xmax):
    '''
    Name: draw_axes
    Inputs: xmin and xmax, which represent the left and right-most points on
            the graph
    Returns: nothing
    Does: draws the x and y axes of a graph
    '''
    turtle.color("black")
    turtle.penup()
    turtle.goto(xmin, YMAX)
    turtle.pendown()
    turtle.goto(xmin, YMIN)
    turtle.goto(xmax, YMIN)
    turtle.penup()

def draw_tick_marks(xmin):
    '''
    Name: draw_tick_marks
    Inputs: xmin, the left-most position on the graph
    Returns: nothing
    Does: draws the tick marks on the y axis, evenly spaced
    '''
    turtle.color("black")
    counter = 0
    while counter <= 20:
        turtle.goto(xmin, YMIN + (counter * 20))
        turtle.pendown()
        turtle.goto(xmin - 5, YMIN + (counter * 20))
        turtle.penup()
        counter += 1

def label_tick_marks(data,xmin):
    '''
    Name: label_tick_marks
    Inputs: data, a list of floats (the dataset to be graphed) and xmin, the
            left-most point on the graph
    Returns: nothing
    Does: labels the tick marks using increments that depend on the inputted
          data
    '''
    turtle.color("black")
    max_tick = max(data)
    scale = max_tick / 20
    counter = 0
    while counter <= 20:
        turtle.goto(xmin - 20, YMIN + (counter * 20))
        label = round(counter * scale, 2)
        turtle.write(label, True, align = "center")
        counter += 1

def label_axis(xmin):
    '''
    Name: label_axis
    Inputs: xmin, the leftmost point on the graph
    Returns: nothing
    Does: labels the y axis with views: Trending/Control
    '''
    
    turtle.color("black")
    turtle.goto(xmin - 100,(YMAX + YMIN) / 2,)
    turtle.setheading(90)
    turtle.write("Views:\nTrending/\nControl")
        

def draw_dots(data,xmin,xmax):
    '''
    Name: draw_dots
    Inputs: data, a list of floats, and xmin and xmax, the left and right most
            points on the graph
    Returns: nothing
    Does: scales the data to fit the graph outline, and plots the scaled data
    '''
    scale_factor = (YMAX - YMIN) / max(data)
    scaled_data = []
    for i in range(len(data)):
        scaled_point = (data[i] * scale_factor) - 200
        scaled_data.append(scaled_point)

    turtle.color("blue")
    
    for element in scaled_data:
        turtle.goto((xmin + xmax) / 2, element)
        turtle.pendown()
        turtle.dot(3)
        turtle.penup()
    
    
    

def draw_average_line(data,xmin,xmax):
    '''
    Name: draw_average_line
    Inputs: data, a list of floats and xmin and xmax, the left and right-most
            points on the graph
    Returns: nothing
    Does: finds the average of the inputted list and draws a horizontal line
          at the corresponding y-value and labels it (placement is done
          according to scale)
    '''
    avg = calculate_average(data)
    scale_factor = (YMAX - YMIN) / max(data)
    scaled_average = (avg * scale_factor) - 200
    turtle.penup()
    turtle.goto(xmin, scaled_average)
    turtle.color("darksalmon")
    turtle.pendown()
    turtle.goto(xmax, scaled_average)
    turtle.write("average = " + str(round(avg,2)), True, align = "center")
    turtle.penup()
                 
    
def graph_all():
    '''
    Name: graph_all
    Inputs: nothing
    Returns: nothing
    Does: creates the graph for all of the data that is clean. Each dot
          represents the average views on a trending video divided by the
          average views on a control/random video, while holding like-
          dislike ratio, comments, and category constant
    '''
    datal = calc_trend_over_control()
    draw_axes(XMINL,XMAXL)
    draw_tick_marks(XMINL)
    label_axis(XMINL)
    turtle.goto((XMAXL + XMINL)/2, YMAX + 20)
    turtle.write("Ratio of Average Views on Trending vs Random Videos,\n"
                 "Controlling for Other Factors", True, align = "center")

    label_tick_marks(datal,XMINL)
    draw_dots(datal,XMINL,XMAXL)
    draw_average_line(datal,XMINL,XMAXL)
  

    
def graph_without_outliers():
    '''
    Name: graph_without_outliers
    Inputs: nothing
    Returns: nothing
    Does: creates the graph for all of the data that is clean, but after
          removing the outliers. Each dot represents the average views on a
          trending video divided by the average views on a control/random
          video, while holding like-dislike ratio, comments, and category
          constant
    '''


    datal = calc_trend_over_control()
    datar = remove_outliers(datal)
    draw_axes(XMINR,XMAXR)
    draw_tick_marks(XMINR)
    label_axis(XMINR)
    turtle.goto((XMAXR + XMINR)/2, YMAX + 20)
    turtle.write("Ratio of Average Views on Trending vs Random Videos,\n"
                 "Controlling for Other Factors (Outliers Removed)", True,
                 align = "center")
    label_tick_marks(datar,XMINR)
    draw_dots(datar,XMINR,XMAXR)
    draw_average_line(datar,XMINR,XMAXR)
    

def draw_graphs():
    '''
    Name: draw_graphs
    Inputs: none
    Returns: nothing, just prints analyses and draws graphs
    Does: prints the views analyses and draws two graphs side by side. The
          graphs plot the ratio of average views on a trending video over
          average views on a random video, controlling for category, comments,
          and like-dislike ratio. The graph on the left uses all of the
          data, whereas the graph on the right excludes outliers.
    '''
    turtle.tracer(False)
    turtle.setup(width = 800,height = 500, startx = None, starty = None)
    turtle.clear()
    view_analysis()
    graph_all()
    graph_without_outliers()
    
draw_graphs()
    

