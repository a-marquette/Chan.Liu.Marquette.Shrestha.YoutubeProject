from ldl_ratio import turnintoint
from ldl_ratio import getratio
from ldl_ratio import getaverageratios
from ldl_ratio import removeoutliers
from ldl_ratio import getincrease
from ldl_ratio import viz


from trending_clean import readCSV

def main():
    '''
    Name: main
    Inputs: None
    Returns: None
    Prints: average likes to dislikes ratio for trending and control videos and
        prints the increase/decrease from the average trending to average
        control --> prints this for both datasets with outliers and without
        outliers
        prints visualization of two scatterplots 
    '''
    #calling and cleaning datasets 
    clean_trending = readCSV("USvideos.csv")
    clean_control = turnintoint()

    #data including outliers
    trend_woutliers = getratio(clean_trending)
    control_woutliers = getratio(clean_control)
    avg_woutliers = getaverageratios(trend_woutliers, control_woutliers)
    print('The average likes to dislikes ratio for trending videos is'
          ,round(avg_woutliers[0],2))
    print('The average likes to dislikes ratio  for the control videos is'
          ,round(avg_woutliers[1],2))
    getincrease(avg_woutliers)

    print()

    #data excloding outliers
    ratio_trend = removeoutliers(clean_trending)
    ratio_control = removeoutliers(clean_control)
    avg = getaverageratios(ratio_trend, ratio_control)
    print('The average likes to dislikes ratio for trending videos without'
          'outliers is',round(avg[0],2))
    print('The average likes to dislikes ratio for the control videos without'
          'outliers is',round(avg[1],2))
    getincrease(avg)

    #creating list of trending ratios, control ratios, average trending ratio,
    #average control ratio, and title for both conditions of including and
    #excluding outliers
    viz_with_outliers = [trend_woutliers, control_woutliers, avg_woutliers[0],
                         avg_woutliers[1],
                         'Likes to Dislikes Ratio, including outliers']
    viz_wo_outliers = [ratio_trend, ratio_control, avg[0], avg[1],
                       'Likes to Dislikes Ratio, excluding outliers']
    viz([viz_with_outliers, viz_wo_outliers])
main()






    
