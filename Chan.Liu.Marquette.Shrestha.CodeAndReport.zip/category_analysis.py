'''
DS 2000
Elise Chan, Ruoxi (Selina) Liu, Alyssa Marquette, Carrline Shrestha
Project
'''
import csv
import matplotlib.pyplot as plt
from trending_clean import CATEGORY_TYPE
from trending_clean import readCSV
from trending_clean import clean_categories
from trending_clean import cleanUp
from control_clean import readControlCSV
from control_clean import get_more_data
from control_clean import cleanCSV

VIEWS = [0,10000,100000,500000,1000000,9999999999999]
COMMENTS = [0,500,2500,5000,9999999999999]
LDLRATIO = [0,5,20,100,9999999999999]
LIKES = [0,500,5000,10000,100000,9999999999999]
DISLIKES = [0,50,250,500,1000,9999999999999]
CATEGORIES = ["Film & Animation", "Autos & Vehicles", "Music", "Pets & Animals",
              "Sports", "Short Movies","Travel & Events", "Gaming",
              "Videoblogging", "People & Blogs","Comedy", "Entertainment",
              "News & Politics", "Howto & Style","Education",
              "Science & Technology", "Nonprofits & Activism", "Movies",
              "Anime/Animation", "Action/Adventure", "Classics", "Documentary",
              "Drama", "Family", "Foreign", "Horror", "Sci-Fi/Fantasy",
              "Thriller", "Shorts", "Shows", "Trailers"]

def categorize_views(dataset):
    '''
    Name: categorize_views
    Input: dataset, a list of lists
    Return: view_categorization, a list

    This function runs through every element in a dataset related to video
    metadata, looks at the number of views associated with an element, and
    classifies the video into one of 5 distinctions based on how many views it
    has. The function then returns a list of these distinctions. 
    '''
    view_categorization = []
    for video in dataset:
        for i in range(len(VIEWS)-1):
            try:
                if video[4] >= VIEWS[i] and video[4] < VIEWS[i+1]:
                    view_categorization.append(i)
            except:
                view_categorization.append(" ")
    return view_categorization


def categorize_ldlratio(dataset):
    '''
    Name: categorize_ldlratio
    Input: dataset, a list of lists
    Return: ldl_categorization, a list

    This function runs through every element in a dataset related to video
    metadata, looks at the like:dislike ratio associated with an
    element, and classifies the video into one of 4 distinctions based on this.
    The function then returns a list of these distinctions. 
    '''
    ldlratio_categorization = []
    for video in dataset:
        for i in range(len(LDLRATIO)-1):
            try:
                if video[2] == 0:
                    ratio = video[3]
                else:
                    ratio = video[3]/video[2]
                
                if ratio >= LDLRATIO[i] and ratio < LDLRATIO[i+1]:
                    ldlratio_categorization.append(i)

            except:
                ldlratio_categorization.append(" ")
    return ldlratio_categorization


def categorize_category(dataset):
    '''
    Name: categorize_category
    Input: dataset, a list of lists
    Return: category_categorization, a list

    This function runs through every element in a dataset related to video
    metadata, looks at the video category, and appends it to a seprate list.
    The function then returns this list.
    '''
    category_categorization = []
    for video in dataset:
        category_categorization.append(video[5])
    return category_categorization


def categorize_comments(dataset):
    '''
    Name: categorize_comment
    Input: dataset, a list of lists
    Return: comment_categorization, a list

    This function runs through every element in a dataset related to video
    metadata, looks at the number of comments associated with an
    element, and classifies the video into one of 4 distinctions based on this.
    The function then returns a list of these distinctions. 
    '''
    comment_categorization = []
    for video in dataset:
        for i in range(len(COMMENTS)-1):
            try:
                if video[1] >= COMMENTS[i] and video[1] < COMMENTS[i+1]:
                    comment_categorization.append(i)
            except:
                comment_categorization.append(" ")
    return comment_categorization


def write_csv(data, file_name):
    '''
    Name: write_csv
    Input: data, a list of lists, and file_name, a string
    Return: nothing

    This function takes the categorized lists from the above functions and
    writes them to a CSV file with a file name as inputted to the function.
    '''
    views = categorize_views(data)
    ldl = categorize_ldlratio(data)
    category = categorize_category(data)
    comments = categorize_comments(data)
    
    new = []

    for i in range(len(category)):
        empty = []
        empty.append(views[i])
        empty.append(ldl[i])
        empty.append(category[i])
        empty.append(comments[i])
        new.append(empty)

    with open(file_name, "w", newline='') as csvFile:
        writer = csv.writer(csvFile)
        writer.writerows(new)
    return

def isolate_factors(file_name, views, ldl, comments, list_name):
    '''
    Name: isolate_factors
    Input: file_name(a string), views(an int), ldl(an int), comments(an int),
        list_name(a list)
    Return: list_name, a list

    This function isolates only the video category factor.
    This function opens a CSV file holding video metadata. If the metadata held
    in a row match all of the inputs, the count of videos that match the
    category data held in that row is incremented by 1. After the entire CSV
    file has been processed, the category with the highest count is apppended
    to the list inputted, and that list is then returned. 
    '''
    with open(file_name) as in_file:
        dict_name = {}
        csv_file = csv.reader(in_file, delimiter = ",")
        for row in csv_file:
            try:
                if int(row[0]) == views:
                    if int(row[1]) == ldl:
                        if int(row[3]) == comments:
                            if row[2] in dict_name:
                                dict_name[row[2]] += 1
                            else:
                                dict_name[row[2]] = 1
            except:
                continue
        max_num = 0
        max_key = "nothing"
        for key in dict_name:
            if dict_name[key] > max_num:
                max_num = dict_name[key]
                max_key = key
        list_name.append(max_key)
    return list_name

def isolate(file_name):
    '''
    Name: isolate
    Input: file_name
    Return: list_name

    Using the distinctions defined for views, like:dislike ratio, and comments,
    this function runs through all 80 control groups used to isolate for
    video category. For each control group, isolate_factors is called and is
    stored in a list. The list is then returned after all 80 control groups
    have been evaluated. 
    '''
    list_name = []
    for a in range(5):
        for b in range(4):
            for c in range(4):
                list_name = isolate_factors(file_name, a, b, c, list_name)
    return list_name

def graph_basic(same, diff):
    '''
    Name: graph_basic
    Input: same and diff, both lists of lists
    Returns: nothing

    This function uses matplotlib to make a pie chart of control groups that
    had matching most popular categories between trending and random vids,
    those that had
    different most popular categoires, and those who could not be compared. 
    '''
    labels = ["yes", "no", "non-applicable"]
    sizes = [(len(same) / 80), (len(diff) / 80), ((80 - len(same) - len(diff)) / 80)]
    
    fig6, ax6 = plt.subplots()
    ax6.set_title("Do the categories match up between controlled trending and random vids?")
    ax6.pie(sizes, labels = labels, autopct = "%1.1f%%")
    ax6.axis("equal")
    return

def graph_same(same):
    '''
    Name: graph_same
    Input: same, a list of lists
    Returns: nothing

    This function uses matplotlib to graph a pie chart of the most popular
    category
    distribution among control groups where categories matched between trending
    and random videos. 
    '''
    s_labels = []
    s_sizes = []
    for element in same:
        if element[1] in s_labels:
            continue
        else:
            s_labels.append(element[1])
    for element in s_labels:
        s_counter = 0
        for i in range(len(same)):
            if same[i][1] == element:
                s_counter+= 1
        s_sizes.append(s_counter / len(same))
        
    fig1, ax1 = plt.subplots()
    ax1.set_title("Category distribution when controlled trending and random category match")
    ax1.pie(s_sizes, labels = s_labels, autopct = "%1.1f%%")
    ax1.axis("equal")
    return

def graph_diff(diff):
    '''
    Name: graph_diff
    Input: diff, a list of lists
    Returns: nothing

    This function uses matplotlib to graph a pie chart of the most popular
    category
    distribution in control groups where the most popular categories didn't
    match
    between trending and random videos. The function graphs both the
    distribution among trending videos, and the distribution among random videos
    '''
    d_labels_t = []
    d_sizes_t = []
    d_labels_c = []
    d_sizes_c = []
    for element in diff:
        if element[1] in d_labels_t:
            continue
        else:
            d_labels_t.append(element[1])
    for element in diff:
        if element[2] in d_labels_c:
            continue
        else:
            d_labels_c.append(element[2])
    for element in d_labels_t:
        t_counter = 0
        for i in range(len(diff)):
            if diff[i][1] == element:
                t_counter += 1
        d_sizes_t.append(t_counter / len(diff))
    for element in d_labels_c:
        c_counter = 0
        for i in range(len(diff)):
            if diff[i][2] == element:
                c_counter += 1
        d_sizes_c.append(c_counter / len(diff))

    fig2, ax2 = plt.subplots()
    ax2.set_title("Category distribution among controlled trending vids when not matched with random vids")
    ax2.pie(d_sizes_t, labels = d_labels_t, autopct = "%1.1f%%")
    ax2.axis("equal")

    fig3, ax3 = plt.subplots()
    ax3.set_title("Category distribution among controlled random vids when not matched with trending vids")
    ax3.pie(d_sizes_c, labels = d_labels_c, autopct = "%1.1f%%")
    ax3.axis("equal")
    return


def graph_basic_cat(trending_cat, control_cat):
    '''
    Name: graph_basic_cat
    Input: trending_cat and control_cat, both lists
    Returns: nothing

    This function uses matplotlib to graph 2 pie charts of the most popular
    category
    distributions among all trending videos and among all random videos.
    '''
    t_labels = []
    t_sizes = []
    for element in trending_cat:
        if element in t_labels:
            continue
        else:
            t_labels.append(element)
    
    for element in t_labels:
        counter = 0
        for i in range(len(trending_cat)):
            if trending_cat[i] == element:
                counter += 1
        t_sizes.append(counter / len(trending_cat))
    fig4, ax4 = plt.subplots()
    ax4.set_title("Category distribution among trending videos")
    ax4.pie(t_sizes, labels = t_labels, autopct = "%1.1f%%")
    ax4.axis("equal")


    c_labels = []
    c_sizes = []
    for element in control_cat:
        if element in c_labels:
            continue
        else:
            c_labels.append(element)
    
    for element in c_labels:
        counter = 0
        for i in range(len(control_cat)):
            if control_cat[i] == element:
                counter += 1
        c_sizes.append(counter / len(control_cat))
    fig5, ax5 = plt.subplots()
    ax5.set_title("Category distribution among random videos")
    ax5.pie(c_sizes, labels = c_labels, autopct = "%1.1f%%", startangle = 130)
    ax5.axis("equal")
    return

def main():
    cleaned_trending = readCSV("USvideos.csv")
    # what's in each element of cleaned_data and cleaned_control
    # [video id, comments, dislikes, likes, views, category, channel, title]
    csv_data = readControlCSV("count_observation_upload.csv")
    cleaned_control = cleanCSV(csv_data)
    # write to a CSV the distinctions for various metadata for trending
    # and random vids
    write_csv(cleaned_trending, "trending_factors.csv")
    write_csv(cleaned_control, "control_factors.csv")

    # store the most popular categories of all trending vids and all random vids
    trending_cat = isolate("trending_factors.csv")
    control_cat = isolate("control_factors.csv")
    
    same = []
    diff = []
    # in each control group, if the most popular category in trending and random
    # matches, append the index position and category to same
    for i in range(len(trending_cat)):
        if trending_cat[i] == control_cat[i] and trending_cat[i] != "nothing":
            # print(i, trending_cat[i], sep = " ")
            same.append([i, trending_cat[i]])

    # in each control group, if the most popular category in trending and random
    # don't match, append the index position and both categories to diff
    for i in range(len(trending_cat)):
        if trending_cat[i] != control_cat[i] and trending_cat[i] != "nothing" and control_cat[i] != "nothing":
            # print(i, trending_cat[i], "   ", control_cat[i], sep = " ")
            diff.append([i, trending_cat[i], control_cat[i]])


    # call all the graphing functions and show the resulting plots
    graph_basic(same, diff)
    graph_same(same)
    graph_diff(diff)
    graph_basic_cat(trending_cat, control_cat)
    plt.show()

    
    
    
    

main()




