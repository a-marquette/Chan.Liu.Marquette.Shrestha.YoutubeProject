'''
DS 2000
Elise Chan, Ruoxi (Selina) Liu, Alyssa Marquette, Carrline Shrestha
Project
'''
import csv
from views import final_view, calculate_average
from numpy import percentile

def calc_trend_over_control():
    '''
    Name: calc_trend_over_control
    Inputs: None
    Returns: tc_ratio, a list of floats. Each value represents the average
             number of views on trending videos divided by the average
             number of cviews on control/random videos. Each number has –a
             different grouping of the control factors.
    Does: For each set of controls, this function finds the average views
          on a trending videos divided by average views on the "random"
          videos. It also removes any groupings of controls where the average
          number of views is 0 to make the numbers more reliable and the
          data easier to work with.
    '''
    all_averages = final_view()
    #print(all_averages)

    tc_ratio = []
    for duo in all_averages:
        if duo[0] == 0 or duo[1] == 0:
            continue
        
        else:
            ratio = duo[0] / duo[1]
            tc_ratio.append(ratio)
    return tc_ratio


def remove_outliers(data):
    '''
    Name: remove_outliers
    Inputs: data, a list of floats from which outliers will be removed
    Returns: data_without_outliers, a list of floats containing no outliers
    Does: removes outliers from a list of data using the interquartile range
          method, where any value that is less than 1.5*inter quartile range
          below the first quartile or more than 1.5*inter quartile range above
          the third quartile is removed.
    '''
    # Method and Code Help from:
    # https://machinelearningmastery.com/how-to-use-statistics-to-identify-outliers-in-data/

    
    q25, q75 = percentile(data,25), percentile(data,75)
    iqr = q75 - q25

    cutoff = iqr * 1.5
    lower = q25 - cutoff
    upper = q75 + cutoff
    
    data_without_outliers = []
    for element in data:
        if element > lower and element < upper:
            data_without_outliers.append(element)

    return data_without_outliers

def percent_trending_lessthan_control(data):
    '''
    Name: percent_trending_exceeding_control
    Inputs: data, a list of floats
    Returns: percent, a float
    Does:
    '''
    counter = 0
    for number in data:
        if number <= 1:
            counter += 1

    percent = (counter / (len(data))) * 100
    return percent

def print_outcomes(data):
    '''
    Name: print_outcomes
    Inputs: data, a list of floats (the trending/control ratio of average
            views, controlled for other factors, with or without outliers)
    Returns: nothing
    Does: Prints out the outline for statements generalizing the results.
    '''
    avg = calculate_average(data)
    percent = percent_trending_lessthan_control(data)

    print("On average, a trending video has", round(avg, 2), "times as many "
          "views as a random video.\n")
    
    print(round(percent,2), "percent of videos sharing control factors had "
          "less views if they were\ntrending than if they were not.")  
    

def view_analysis():
    tc_ratio = calc_trend_over_control()
    no_outliers = remove_outliers(tc_ratio)
    
    print("When category, like-dislike ratio, and number of comments on a video"
          " are\ncontrolled for, the following results regarding number of "
          "views on a video\nwere found in our dataset:\n")

    print_outcomes(tc_ratio)
    print("\n\n")
    
    print("If outliers are removed, the following results were found in our "
          "dataset:\n")

    print_outcomes(no_outliers)







