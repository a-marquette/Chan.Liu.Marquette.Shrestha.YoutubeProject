'''
DS 2000
Elise Chan, Ruoxi(Selina) Liu, Alyssa Marquette, Carrline Shrestha
Project
'''

import matplotlib.pyplot as plt
import numpy as np 
from numpy import percentile
import csv

from trending_clean import readCSV
from control_clean import readControlCSV
from control_clean import cleanCSV


#data = [video id, comments, dislikes, likes, views, category, channel, title]

VIEWS = [0,10000,100000,500000,1000000,9999999999999]
COMMENTS = [0,500,2500,5000,9999999999999]
LDLRATIO = [0,5,20,100,9999999999999]
LIKES = [0,500,5000,10000,100000,9999999999999]
DISLIKES = [0,50,250,500,1000,9999999999999]
CATEGORIES = ["Film & Animation", "Autos & Vehicles", "Music", "Pets & Animals",
              "Sports", "Short Movies","Travel & Events", "Gaming",
              "Videoblogging", "People & Blogs","Comedy", "Entertainment",
              "News & Politics", "Howto & Style","Education",
              "Science & Technology", "Nonprofits & Activism", "Movies",
              "Anime/Animation", "Action/Adventure", "Classics", "Documentary",
              "Drama", "Family", "Foreign", "Horror", "Sci-Fi/Fantasy",
              "Thriller", "Shorts", "Shows", "Trailers"]

def turnintoint():
    '''
    Name: turnintoint
    Inputs: none
    Returns: control_data, list of cleaned control dataset
    Does: Turns numbers from string to ints in the dataset
    '''
    control = readControlCSV("count_observation_upload.csv")
    control_data = cleanCSV(control)
    for row in control_data:
        for i in range(1,5):
            row[i] = int(float(row[i]))
    return control_data

def controlviews(data):
    '''
    Name: controlviews
    Inputs: data, a list of cleaned data
    Returns: cat_views, a list of the assigned category value of views
    Does: Instead of having the number of views for each video, this function
          assigns a value based on the range the actual number of views falls in.
          0: views < 10,000
          1: 10,000 <= views <100,000
          2: 100,000 <= views < 500,000
          3: 500,000 <= views < 1 mil
          4: views >= 1mil
    '''
    cat_views = []
    for value in data:
        for i in range(len(VIEWS) - 1):
            try:
                if value[4] >= VIEWS[i] and value[4] < VIEWS[i + 1]:
                    cat_views.append(i)
            except:
                cat_views.append(' ')
    return cat_views

def controlcomments(data):
    '''
    Name: controlcommments
    Input: data, a list of lists
    Return: cat_comments, a list
    This function runs through every element in a dataset related to video
    metadata, looks at the number of comments associated with an
    element, and classifies the video into one of 4 distinctions based on this.
    The function then returns a list of these distinctions. 
    '''
    cat_comments = []
    for value in data:
        for i in range(len(COMMENTS) - 1):
            try:
                if value[1] >= COMMENTS[i] and value[1] < COMMENTS[i + 1]:
                    cat_comments.append(i)
            except:
                cat_comments.append(' ')
    return cat_comments
            
def controlcategories(data):
    '''
    Name: control
    Inputs: dataset, a list of cleaned data
    Returns: category_categorization, a list of the assigned value for each
             category
    Does: Instead of having the category name for each video, this function
          assigns a value based on the name of the category, and the list of
          categories is edited down to only categories which the videos being
          analyzed hold. See CATEGORIES list to determine the category. For
          example, 0 = Film & Animation, 1 = Autos & Vehicles, etc.
    '''
    cat_categories = []
    for value in data:
        for i in range(len(CATEGORIES)):
            try:
                if value[5] == CATEGORIES[i]:
                    cat_categories.append(i)
            except:
                cat_categories.append(' ')
    return cat_categories 

def get_video_id(data):
    '''
    Name: get_video_id
    Inputs: data, a list of cleaned data
    Returns: video_id, a list of the video ids in order
    Does: lists the video ids in order that the other factors are listed (to be
          used later to keep track of videos by tracking their unique
          identifier)
    '''
    video_id = []
    for value in data:
        video_id.append(value[0])
    return video_id


def categorized_list(data):
    '''
    Name: categorized_list
    Inputs: data, a list of cleaned data
    Returns: cleaned_info, a list of videos where the first element is
             video id (str), followed by views category (int),comments
             category (int), and categories category (str)
    Does: Makes a list of video id and the desired factors to control for (in
          their categorized form) for each video
    '''
    views = controlviews(data)
    categories = controlcategories(data)
    comments = controlcomments(data)
    video_id = get_video_id(data)

    cleaned_info = []

    for i in range(len(categories)):
        row = []
        row.append(video_id[i])
        row.append(views[i])
        row.append(comments[i])
        row.append(categories[i])
        cleaned_info.append(row)
    #cleaned_info = [video_id, views, comments, categories]
    return cleaned_info 


def similarvids(views, comments, categories, listname):
    '''
    Name: similarvids
    Inputs: views (the number of the grouping of the number of views to be
            analyzed (0, 1, 2, 3, or 4)), comments (the number of comments to be
            analyzed (0, 1, 2, or 3), categories (0-31, representing the
            position on the CATEGORIES list that the video in question's
            category matches with), and listname(the name of the list that
            categorizes all desired factors),
    Returns: similar_vids, a list whose elements are videos ids for videos that
             share the views categorization, comments categorization, and
             category categorization that was inputted
    Does: groups the video ids for videos sharing the a cetain set of control
          factors
    '''
    similar_vids = []
    for value in listname:
        if value[1] == views and value[2] == comments and value[3] == categories:
            similar_vids.append(value[0])
    return similar_vids 

def isolate(data):
    '''
    Name: isolate
    Input: data (list of cleaned dataset)
    Returns: groups, a list of lists where the inner lists contain the video
             ids for videos sharing an individual set of control factors. If no
             videos meet the certain criteria, there is an empty list. The
             outer list contains all groupings possible that can be made with
             the desired factors. 
    Does: makes separate lists for the video ids of all videos sharing the same
          control factors, for all possible groupings of control factors that
          are being looked at
    '''
    groups = []
    list_name = categorized_list(data)
    for c in range(len(CATEGORIES)):
        #for comments categorization
        for b in range(4):
            #for views categorization
            for a in range(5):
                groups.append(similarvids(a, b, c, list_name))
    return groups

def id_to_ldl(data):
    '''
    Name: id_to_ldl
    Inputs: data (list of clean data) 
    Returns: idl_list, a list of lists where the inner lists contain the likes
            and dislikes count in a list for the videos that share the set of
            control factors.
            If no videos meet the certain criteria, there is an empty list.
    Does: While isolate makes the groups of videos sharing the control
          characteristics and specifies videos by their video id, this function
          creates a new list, taking the video id and finding the coreresponing
          likes and dislikes count for the video. 
    '''
    groups = isolate(data)
    ldl_list = []
    for group in groups:
        for i in range(len(group)):
            for j in range(len(data)):
                if group[i] == data[j][0]:
                    ldl = [data[j][3], data[j][2]]
                    ldl_list.append(ldl)
    return ldl_list

def getratio(file):
    '''
    Name: getratio
    Inputs: file (list of clean data)
    Returns: ratio_list, a list of ratios for the videos that fit the criteria
        when views, comments, and categories are controlled
    Does: Gets the ratio of likes to dislikes by dividing the likes by the
        dislikes. Videos that have no data or have a total of 0 likes and
        dislikes were ignored. If a video had no dislikes, the ratio is the
        total number of likes 
    '''
    data = id_to_ldl(file)
    ratio_list = []
    count_none = 0
    count_zero = 0
    for i in range(len(data)):
        #likes does not have data 
        if data[i][0] == ' ':
            count_none += 1
        else:
            likes = data[i][0]
            dislikes = data[i][1]
            total = likes + dislikes
            if dislikes != 0:
                ratio = likes / dislikes
                ratio_list.append(ratio)
            # likes and dislikes = 0
            elif total == 0:
                count_zero += 1
            # no dislikes
            elif dislikes == 0:
                ratio = likes
                ratio_list.append(ratio)
    return ratio_list

def removeoutliers(file):
    '''
    Name: remove_outliers
    Inputs: file (list of clean data)
    Returns: data_without_outliers, a list of floats containing no outliers
    Does: removes outliers from a list of data using the interquartile range
          method, where any value that is less than 1.5*inter quartile range
          below the first quartile or more than 1.5*inter quartile range above
          the third quartile is removed.
    '''
    data = getratio(file)
    q25, q75 = percentile(data,25), percentile(data,75)
    iqr = q75 - q25

    cutoff = iqr * 1.5
    lower = q25 - cutoff
    upper = q75 + cutoff

    data_without_outliers = []
    for element in data:
        if element > lower and element < upper:
            data_without_outliers.append(element)

    return data_without_outliers
    

def makesamelength(data1, data2):
    '''
    Name: makesamelength
    Inputs: data1, data2 - two lists of data
    Returns: data1, data2 - two lists of data, now botht the same length
    Does: Finds the dataset that is shorter in length and removes the data
        points in the other dataset to make it the same length.
    '''
    if len(data1) > len(data2):
        i = len(data2)
        while len(data1) > len(data2):
            del(data1[i])

    elif len(data1) < len(data2):
        i = len(data1)
        while len(data1) < len(data2):
            del(data2[i])
    return data1, data2

def getaverageratios(data1, data2):
    '''
    Name: getaverageratios
    Inputs: data1, data2 - two lists of data
    Returns: average_list, list of two datapoint of averages, one for each of
        the two inputs
    Does: finds the average ratio of both data inputs and adds them both a list 
    '''
    data_list = makesamelength(data1, data2)
    average_list = []
    
    i = 0
    while i < 2:
        count = 0
        total = 0
        for value in data_list[i]:
            total += value
            count += 1
        average = round(total/count,8)
        average_list.append(average)
        i += 1
    return average_list

def getincrease(avg_list):
    '''
    Name: getincrease
    Inputs: avg_list, list of two data points that represent the averaged ratios
        for the trending and control videos
    Returns: none
    Prints: Whether the ratio for trending videos show an increase or decrease
        compared to control videos and by how much
    Does: Calculates change when comparing trending and control ratios and
        prints whether it is an increase or decrease based on whether the
        change is greater than or less than one
    '''
    #trending = avg_list[0]
    #control = avg_list[1]
    increase = ((avg_list[0] - avg_list[1]) / avg_list[1]) + 1

    #increase > 100 = increase
    #increase < 100 = decrease
    if increase > 1:
        print('Trending videos show a ',round(increase,2),'times increase '
              'compared to control videos.')
    elif increase < 1:
        print('Trending videos show a ',round(increase,2),'times decrease '
              'compared to control videos.')
    else:
        print('The ratios for both the trending and control videos are the same')

def viz(datalist):
    '''
    Name: viz
    Inputs: datalist, a list of two lists with information of trending ratios,
        control ratios, average trending ratio, average control ratio, and
        title within the inner list
    Returns: vizualization of two scatterplots (for each of the lists within the
        dataset) showing the ratios as points and showing an average line
        whether the average for the data exists
    Does: creates two subplots to plot both graphs at once, plots the points
        for each list within the dataset for both trending and control (each in
        its own color), creates an average line based on the input for the
        average ratio for both trending and control, labels the graph and the
        y-axis, and includes a legend 
    '''
    #[0] = trending ratios
    #[1] = control ratios
    #[2] = average trending ratio
    #[3] = average control ratio
    #[4] = title

    i = 1
    for data in datalist:
        #get maximum x value
        x1 = range(len(data[0]))
        #get maximum y value -- based on whether the greatest trending ratio is
        #bigger or the greater control ratio is bigger 
        if int(max(data[0])) > int(max(data[1])):
            y1 = int(max(data[0]) + 50)
        else:
            y1 = int(max(data[1]) + 50)

        #create subplots (num of rows, num of columns, location of chart)
        plt.subplot(1, 2, i)

        #plotting trending and control scatter points 
        plt.plot(x1, data[0],'.',color='red', label = 'Trending')
        plt.plot(x1, data[1],'.', color = 'blue', label = 'Control')

        #plotting and labeling average lines 
        plt.plot([-50, max(x1) + 100], [data[2], data[2]], 'k-',
                 lw=3, color = 'black', label = 'Trending Average')
        plt.text(max(x1) + 190, data[2],'Avg = %.2f'%(data[2]),
                 fontsize = 7)
        plt.plot([-50, max(x1) + 100], [data[3], data[3]], 'r--',
                 lw=3, color = 'black', label = 'Control Average')
        plt.text(max(x1) + 190, data[3] - (.01*y1), 'Avg = %.2f'%(data[3]),
                fontsize = 7)
        
        plt.title(data[4], fontsize = '9')
        plt.ylim(0, y1)
        plt.legend(prop={'size': 6})
        #labeling y axis for the leftmost graph 
        if i == 1:
            plt.ylabel('Ratios of likes to dislikes', fontsize=8)
        i += 1

    #adding space between the graphs 
    plt.subplots_adjust(wspace = .4)
    plt.show()
    
