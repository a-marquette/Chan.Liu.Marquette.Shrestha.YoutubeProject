'''
    DS 2000
    Elise Chan, Selina (Ruoxi) Liu, Alyssa Marquette, Carrline Shrestha
    Project
'''

import csv
from trending_clean import CATEGORY_TYPE

def readControlCSV(file_name):
    '''
    Name: readControlCSV
    Input: file_name, a string
    Returns: csv_data, a list of lists

    this function opens the csv file and stores the data in a list
    '''
    with open(file_name, encoding = "utf8") as in_file:
        csv_file = csv.reader(in_file, delimiter = ",")
        csv_data = []
        bool_counter = True
        counter = 0
        for row in csv_file:
            if bool_counter == False:
                for i in range(len(row)):
                    if i == 1 and row[i] == "0":
                        csv_data.append(row)
            bool_counter = False
            counter += 1
            if counter == 10000000:
                break
    return csv_data

def get_more_data(file_name, csv_data):
    '''
    Name: get_more_data
    Input: file_name, a string, and csv_data, a list of lists
    Returns: csv_data, a list of lists

    this function opens a file with secondary metadata for the control dataset
    and appends it to the corresponding video
    '''
    with open(file_name, encoding = "utf8") as in_file:
        read_file = csv.reader(in_file, delimiter = ",")
        bool_counter = True
        for row in read_file:
            #print(row)
            if bool_counter == False:
                for i in range(len(csv_data)):
                    #print(i)
                    if csv_data[i][0] in row:
                        csv_data[i].append(int(row[2]))
                        csv_data[i].append(row[4])
                        csv_data[i].append(row[8])
                        #print(i)
                        #print(csv_data[i])
                        break
            bool_counter = False
    return csv_data
        

def cleanCSV(csv_data):
    '''
    Name: cleanCSV
    Input: csv_data
    Returns: csv_data

    this function deletes irrelevant info, makes all numbers integers, changes
    category ids to their actual category names, and deletes rows that do not
    have corresponding category data
    '''
    for i in range(len(csv_data)):
        del csv_data[i][13]
        del csv_data[i][12]
        del csv_data[i][11]
        del csv_data[i][10]
        del csv_data[i][9]
        del csv_data[i][8]
        del csv_data[i][5]
        del csv_data[i][1]
        del csv_data[i][0]
        try:
            csv_data[i][1] = int(csv_data[i][1])
            csv_data[i][2] = int(csv_data[i][2])
            csv_data[i][3] = int(csv_data[i][3])
            csv_data[i][4] = int(csv_data[i][4])
        except:
            continue
    csv_data = get_more_data("video_characteristics_upload.csv", csv_data)
    for i in range(len(csv_data)):
        #print(i)
        try:
            csv_data[i][5] = CATEGORY_TYPE[csv_data[i][5]]
        except:
            continue
    counter = 0
    for i in range(len(csv_data)):
        try:
            while len(csv_data[i]) == 5:
                del csv_data[i]
        except:
            continue
    return csv_data

def get_clean_control_data():
    csv_data = readControlCSV("count_observation_upload.csv")
    cleaned_control_data = cleanCSV(csv_data)
    return cleaned_control_data
