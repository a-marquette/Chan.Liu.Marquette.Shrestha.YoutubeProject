'''
    DS 2000
    Elise Chan, Selina (Ruoxi) Liu, Alyssa Marquette, Carrline Shrestha 
    Project
'''

CATEGORY_TYPE = ["nothing", "Film & Animation", "Autos & Vehicles", "nothing",
                 "nothing", "nothing", "nothing", "nothing", "nothing",
                 "nothing", "Music", "nothing", "nothing", "nothing", "nothing",
                 "Pets & Animals", "nothing", "Sports", "Short Movies",
                 "Travel & Events", "Gaming", "Videoblogging", "People & Blogs",
                 "Comedy", "Entertainment", "News & Politics", "Howto & Style",
                 "Education", "Science & Technology", "Nonprofits & Activism",
                 "Movies", "Anime/Animation", "Action/Adventure", "Classics",
                 "Comedy", "Documentary", "Drama", "Faily", "Foreign", "Horror",
                 "Sci-Fi/Fantasy", "Thriller", "Shorts", "Shows", "Trailers"]

import csv

def readCSV(file_name):
    '''
    Name: readCSV
    Input: file_name, a string
    Returns: csv_data, a list of lists

    this function opens the csv file and stores the data in a list
    '''
    with open(file_name, encoding = "utf8") as in_file:
        csv_file = csv.reader(in_file, delimiter = ",")
        cleaned_data = []
        bool_counter = True
        for row in csv_file:
            if bool_counter == False:
                cleaned_data = cleanUp(row, cleaned_data)
            bool_counter = False
    cleaned_data = clean_categories(cleaned_data)
    return cleaned_data

def clean_categories(cleaned_data):
    '''
    Name: clean_categories
    Input: cleaned_data, a list of lists
    Returns: cleaned_data, a list of lists

    this function changes all of the youtube category ids to the actual category
    names each id represents
    '''
    for i in range(len(cleaned_data)):
        cleaned_data[i][5] = CATEGORY_TYPE[cleaned_data[i][5]]
    return cleaned_data
        
def cleanUp(row, cleaned_data):
    '''
    Name: cleanUp
    Input: csv_data, a list of lists
    Returns: cleaned_data, a list of lists

    this function cleans up the original csv data by turning all of the
    numbers into integers and deleting irrelevant data or data that has already
    been stored elsewhere
    '''
    row[10] = int(float(row[10]))
    row[9] = int(float(row[9]))
    row[8] = int(float(row[8]))
    row[7] = int(float(row[7]))
    row[4] = int(float(row[4]))
    # id, comments, dislikes, likes, views, category, channel, title
    if len(cleaned_data) == 0:
        cleaned_data.append([row[0], row[10], row[9],
                            row[8], row[7], row[4],
                            row[3], row[2]])
    bool_counter = True
    for j in range(len(cleaned_data)):
        if row[0] == cleaned_data[j][0]:
            bool_counter = False
    if bool_counter == True:
        cleaned_data.append([row[0], row[10], row[9],
                            row[8], row[7], row[4],
                            row[3], row[2]])
    return cleaned_data


