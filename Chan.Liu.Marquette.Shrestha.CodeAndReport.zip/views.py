'''
    DS 2000
    Elise Chan, Selina (Ruoxi) Liu, Alyssa Marquette, Carrline Shrestha 
    Project
'''
import csv
from control_clean import readControlCSV, cleanCSV
from trending_clean import readCSV

VIEWS = [0,10000,100000,500000,1000000,9999999999999]
# bounderies of view catagories
COMMENTS = [0,500,2500,5000,9999999999999]
LDLRATIO = [0,5,20,100,9999999999999]#
LIKES = [0,500,5000,10000,100000,9999999999999]#
DISLIKES = [0,50,250,500,1000,9999999999999]
CATEGORIES = ["Film & Animation", "Autos & Vehicles", "Music", "Pets & Animals",
              "Sports", "Short Movies","Travel & Events", "Gaming",
              "Videoblogging", "People & Blogs","Comedy", "Entertainment",
              "News & Politics", "Howto & Style","Education",
              "Science & Technology", "Nonprofits & Activism", "Movies",
              "Anime/Animation", "Action/Adventure", "Classics", "Documentary",
              "Drama", "Family", "Foreign", "Horror", "Sci-Fi/Fantasy",
              "Thriller", "Shorts", "Shows", "Trailers"]

def categorize_views(clean_data):#4
    '''
    Name: categorize_views
    Inputs: views from cleaned data sets
    Returns: view_categorization, a list of the assigned category value of views
    Does: Instead of having the number of views for each video, this function
          assigns a value based on the range the actual number of views falls in.
          0: views < 10,000
          1: 10,000 <= views <100,000
          2: 100,000 <= views < 500,000
          3: 500,000 <= views < 1 mil
          4: views >= 1mil
    '''
    view_categorization = []
    for video in clean_data:
        for i in range(len(VIEWS)):
                if  video[4] >= VIEWS[i] and video[4] < VIEWS[i+1]:
                    view_categorization.append(i)
               
    return view_categorization

def categorize_ldlratio(clean_data):
    '''
          0: likes/dislikes < 5
          1: 5 <= likes/dislikes < 20
          2: 20 <= likes/dislikes < 100
          3: likes/dislikes >= 100    
    '''
    ldlratio_categorization = []
    for video in clean_data:
        for i in range(len(LDLRATIO)):
            try:
                if video[2] == 0:
                    ratio = video[3]
                else:
                    ratio = video[3]/video[2]
                
                if ratio >= LDLRATIO[i] and ratio < LDLRATIO[i+1]:
                    ldlratio_categorization.append(i)

            except:
                ldlratio_categorization.append(" ")

    #print('LDL = ',ldlratio_categorization)
    return ldlratio_categorization


def categorize_category(clean_data):
    
    category_categorization = []
    for video in clean_data:
        for i in range(len(CATEGORIES)):
            try:
                if video[5] == CATEGORIES[i]:
                    category_categorization.append(i)
            except:
                category_categorization.append(" ")
   
    return category_categorization


def categorize_comment(clean_data):
    
    comment_categorization = []
    for video in clean_data:
        for i in range(len(COMMENTS)-1):
            try:
                if video[1] >= COMMENTS[i] and video[1] < COMMENTS[i+1]:
                    comment_categorization.append(i)
            except:
                comment_categorization.append(" ")

    #print('comment = ',comment_categorization)
    return comment_categorization


# START seperating groups
def standardize(clean_data):
    #[videoid, ldlratio, comment, category]

    ldlratio_categ = categorize_ldlratio(clean_data)
    category_categ = categorize_category(clean_data)
    comment_categ = categorize_comment(clean_data)    

    clean_category_info = []

    for i in range(len(category_categ)):
        column_data = []
        column_data.append(clean_data[i][0]) # video ids
        column_data.append(ldlratio_categ[i])
        column_data.append(comment_categ[i])
        column_data.append(category_categ[i])
        clean_category_info.append(column_data)

    return clean_category_info


def group_similar_vedios(standard,ratiocat,comcat,catcat):
    similar_vids = []
    for video in standard:
        if video[1] == ratiocat and video[2] == comcat and video[3] == catcat:
            similar_vids.append(video[0])
    return similar_vids


def grouping(standard):
    #[videoid, ldlratio 0-3, comment 0-3, category]
    groups=[]

    s = standard 
    for i in range (len(CATEGORIES)):
        for ratiocat in range(4):
            for comcat in range(4):
                a = group_similar_vedios(s,ratiocat,comcat,i)
                #if a != []:# get rid of the empty lists
                groups.append(a)
    return groups


def change_id_to_views(data_clean,groups):
    for group in groups:
        for i in range(len(group)):
            for j in range(len(data_clean)):
                if group[i]==data_clean[j][0]:
                    group[i]=float(data_clean[j][4])
    return groups

def pair_groups(tid_groups,cid_groups):

    all_pairs = []
    for i in range(len(tid_groups)):
        pairs = []
        pairs.append(tid_groups[i])
        pairs.append(cid_groups[i])
        all_pairs.append(pairs)
        
    #print(all_pairs)
    return all_pairs


def calculate_average(num_list):
    '''
    Name: calculate_average
    Inputs: num_list, a list of numbers (floats or integers)
    Returns: avg, a float representing the average of the inputted numbers
    Does: calculates the average of numbers on a list
    '''

    avg = sum(num_list) / len(num_list)
    return avg
        

def average_views_per_group(tid_groups,cid_groups):
    
    all_pairs = pair_groups(tid_groups,cid_groups)
    all_averages = []
    for pair in all_pairs:
        pairs = []
        for views in pair:
            try:
                avg = calculate_average(views)
                pairs.append(avg)
            except:
                continue
        if len(pairs) == 2:
            all_averages.append(pairs)
            
    return all_averages



#######this file do not need main()######

def final_view():
    trending_clean = readCSV('USvideos.csv')
    #print(trending_clean)
    trending_standard = standardize(trending_clean)
    #print(trending_standard)
    trending_groups = grouping(trending_standard)
    tid_groups = change_id_to_views(trending_clean,trending_groups)
    #print(tid_groups)
    
    control_reader = readControlCSV('count_observation_upload.csv')
    control_clean = cleanCSV(control_reader)
    #print(control_clean)
    control_standard = standardize(control_clean)
    #print(control_standard)
    control_groups = grouping(control_standard)
    cid_groups = change_id_to_views(control_clean,control_groups)
    #print(cid_groups)

    all_averages = average_views_per_group(tid_groups,cid_groups)
    return(all_averages)
    

    
    
