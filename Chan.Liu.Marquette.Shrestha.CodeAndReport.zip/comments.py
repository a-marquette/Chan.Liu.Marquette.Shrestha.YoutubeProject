'''
DS 2000
Elise Chan, Ruoxi (Selina) Liu, Alyssa Marquette, Carrline Shrestha
Project
'''
import csv

from trending_clean import readCSV
from control_clean import get_clean_control_data

#[video id, comments, dislikes, likes, views, category, channel, title]

VIEWS = [0,10000,100000,500000,1000000,9999999999999]
COMMENTS = [0,500,2500,5000,9999999999999]
LDLRATIO = [0,5,20,100,9999999999999]
LIKES = [0,500,5000,10000,100000,9999999999999]
DISLIKES = [0,50,250,500,1000,9999999999999]
CATEGORIES = ["Film & Animation", "Autos & Vehicles", "Music", "Pets & Animals",
              "Sports", "Short Movies","Travel & Events", "Gaming",
              "Videoblogging", "People & Blogs","Comedy", "Entertainment",
              "News & Politics", "Howto & Style","Education",
              "Science & Technology", "Nonprofits & Activism", "Movies",
              "Anime/Animation", "Action/Adventure", "Classics", "Documentary",
              "Drama", "Family", "Foreign", "Horror", "Sci-Fi/Fantasy",
              "Thriller", "Shorts", "Shows", "Trailers"]

all_trending = readCSV("USvideos.csv")
all_control = get_clean_control_data()

def categorize_views(dataset):
    '''
    Name: categorize_views
    Inputs: dataset, a list of cleaned data
    Returns: view_categorization, a list of the assigned category value of views
    Does: Instead of having the number of views for each video, this function
          assigns a value based on the range the actual number of views falls in.
          0: views < 10,000
          1: 10,000 <= views <100,000
          2: 100,000 <= views < 500,000
          3: 500,000 <= views < 1 mil
          4: views >= 1mil
    '''
    view_categorization = []
    for video in dataset:
        for i in range(len(VIEWS)-1):
            try:
                if video[4] >= VIEWS[i] and video[4] < VIEWS[i+1]:
                    view_categorization.append(i)
            except:
                view_categorization.append(" ")
    return view_categorization

def categorize_ldlratio(dataset):
    '''
    Name: categorize_ldlratio
    Inputs: dataset, a list of cleaned data
    Returns: ldlratio_categorization, a list of the assigned category value the
             like-dislike ratio (likes/dislikes)
    Does: Instead of having the value of like-dislike ratio for each video,
          this function assigns a value based on the range the actual ratio
          is in.
          0: likes/dislikes < 5
          1: 5 <= likes/dislikes < 20
          2: 20 <= likes/dislikes < 100
          3: likes/dislikes >= 100
          
    '''
    ldlratio_categorization = []
    for video in dataset:
        for i in range(len(LDLRATIO)-1):
            try:
                if video[2] == 0:
                    ratio = video[3]
                else:
                    ratio = video[3]/video[2]
                
                if ratio >= LDLRATIO[i] and ratio < LDLRATIO[i+1]:
                    ldlratio_categorization.append(i)

            except:
                ldlratio_categorization.append(" ")

    return ldlratio_categorization

def categorize_category(dataset):
    '''
    Name: categorize_category
    Inputs: dataset, a list of cleaned data
    Returns: category_categorization, a list of the assigned value for each
             category
    Does: Instead of having the category name for each video, this function
          assigns a value based on the name of the category, and the list of
          categories is edited down to only categories which the videos being
          analyzed hold. See CATEGORIES list to determine the category. For
          example, 0 = Film & Animation, 1 = Autos & Vehicles, etc.
    '''
    category_categorization = []
    for video in dataset:
        for i in range(len(CATEGORIES)):
            try:
                if video[5] == CATEGORIES[i]:
                    category_categorization.append(i)
            except:
                category_categorization.append(" ")
    return category_categorization

def categorize_likes(dataset):
    '''
    Name: categorize_likes
    Inputs: dataset, a list of cleaned data
    Returns: like_categorization, a list of the assigned category value of likes
    Does: Instead of having the number of likes for each video, this function
          assigns a value based on the range the actual number of likes falls in.
          0: likes < 500
          1: 500 <= likes < 5,000
          2: 5,000 <= likes < 10,000
          3: 10,000 <= likes < 100,000
          4: likes >= 100,000
    '''
    like_categorization = []
    for video in dataset:
        for i in range(len(LIKES)-1):
            try:
                if video[3] >= LIKES[i] and video[3] < LIKES[i+1]:
                    like_categorization.append(i)
            except:
                like_categorization.append(" ")
    return like_categorization

def categorize_dislikes(dataset):
    '''
    Name: categorize_dislikes
    Inputs: dataset, a list of cleaned data
    Returns: dislike_categorization, a list of the assigned category value of
             dislikes
    Does: Instead of having the number of dislikes for each video, this function
          assigns a value based on the range the actual number of dislikes
          falls in.
          0: dislikes < 50
          1: 50 <= dislikes < 250
          2: 250 <= dislikes < 500
          3: 500 <= dislikes < 1,000
          4: dislikes >= 1,000
    '''
    dislike_categorization = []
    for video in dataset:
        for i in range(len(DISLIKES)-1):
            try:
                if video[2] >= DISLIKES[i] and video[2] < DISLIKES[i+1]:
                    dislike_categorization.append(i)
            except:
                dislike_categorization.append(" ")
    return dislike_categorization

def categorize_comments(dataset):
    '''
    Name: categorize_comments
    Inputs: dataset, a list of cleaned data
    Returns: comment_categorization, a list of the assigned category value of
             comments
    Does: Instead of having the number of comments for each video, this function
          assigns a value based on the range the actual number of comments
          falls in.
          0: comments < 500
          1: 500 <= comments < 2,500
          2: 2,500 <= comments < 5,000
          3: comments >= 5,000
    '''
    comment_categorization = []
    for video in dataset:
        for i in range(len(COMMENTS)-1):
            try:
                if video[1] >= COMMENTS[i] and video[1] < COMMENTS[i+1]:
                    comment_categorization.append(i)
            except:
                comment_categorization.append(" ")
    return comment_categorization

def isolate_video_id(dataset):
    '''
    Name: isolate_video_id
    Inputs: dataset, a list of cleaned data
    Returns: vid_id, a list of the video ids in order
    Does: lists the video ids in order that the other factors are listed (to be
          used later to keep track of videos by tracking their unique
          identifier)
    '''
    vid_id = []
    for video in dataset:
        identification = video[0]
        vid_id.append(identification)
    return vid_id


def make_categorized_factors_lists(dataset):
    '''
    Name: make_categorized_factors_lists
    Inputs: dataset, a list of cleaned data
    Returns: clean_category_info, a list of videos where the first element is
             video id, followed by like-dislike ratio category, views category,
             and category category (all integers)
    Does: Makes a list of video id and the desired factors to control for (in
          their categorized form)for each video
    '''
    video_id = isolate_video_id(dataset)
    ratio_all = categorize_ldlratio(dataset)
    views_all = categorize_views(dataset)
    category_all = categorize_category(dataset)
    
    clean_category_info = []

    for i in range(len(category_all)):
        column_data = []
        column_data.append(video_id[i])
        column_data.append(ratio_all[i])
        column_data.append(views_all[i])
        column_data.append(category_all[i])
        clean_category_info.append(column_data)

    return clean_category_info

#[videoid, ldlratio, views, category]


def group_similar_videos(listname,ratiocat,viewscat,catcat):
    '''
    Name: group_similar_videos
    Inputs: listname(the name of the list that categorizes all desired factors),
            ratiocat(the number for the grouping of the like-dislike ratio to
            be analyzed (0, 1, 2, or 3)), viewscat(the number of the grouping
            of the number of views to be analyzed (0, 1, 2, 3, or 4)), and 
            catcat(0-31, representing the position on the CATEGORIES list that
            the video in question's category matches with)
    Returns: similar_vids, a list whose elements are videos ids for videos that
             share the views categorization, like-dislike ratio, and category
             categorization that was inputted
    Does: groups the video ids for videos sharing the a cetain set of control
          factors
    '''
    similar_vids = []
    for video in listname:
        if video[1] == ratiocat and video[2] == viewscat and video[3] == catcat:
            similar_vids.append(video[0])
    return similar_vids


def form_all_groups(dataset):
    '''
    Name: form_all_groups
    Inputs: dataset (name of clean dataset)
    Returns: groups, a list of lists where the inner lists contain the video
             ids for videos sharing an individual set of control factors. If no
             videos meet the certain criteria, there is an empty list. The
             outer list contains all groupings possible that can be made with
             the desired factors. 
    Does: makes separate lists for the video ids of all videos sharing the same
          control factors, for all possible groupings of control factors that
          are being looked at
    '''
    groups = []
    a = make_categorized_factors_lists(dataset)
    for i in range(len(CATEGORIES)):
        groups.append(group_similar_videos(a,0,0,i))
        groups.append(group_similar_videos(a,0,1,i))
        groups.append(group_similar_videos(a,0,2,i))
        groups.append(group_similar_videos(a,0,3,i))
        groups.append(group_similar_videos(a,0,4,i))
        groups.append(group_similar_videos(a,1,0,i))
        groups.append(group_similar_videos(a,1,1,i))
        groups.append(group_similar_videos(a,1,2,i))
        groups.append(group_similar_videos(a,1,3,i))
        groups.append(group_similar_videos(a,1,4,i))
        groups.append(group_similar_videos(a,2,0,i))
        groups.append(group_similar_videos(a,2,1,i))
        groups.append(group_similar_videos(a,2,2,i))
        groups.append(group_similar_videos(a,2,3,i))
        groups.append(group_similar_videos(a,2,4,i))
        groups.append(group_similar_videos(a,3,0,i))
        groups.append(group_similar_videos(a,3,1,i))
        groups.append(group_similar_videos(a,3,2,i))
        groups.append(group_similar_videos(a,3,3,i))
        groups.append(group_similar_videos(a,3,4,i))
    return groups

def change_id_to_comments(dataset):
    '''
    Name: change_id_to_comments
    Inputs: dataset (cleaned dataset)
    Returns: groups, a list of lists where the inner lists contain the comment
             count for videos sharing an individual set of control factors.
             If no videos meet the certain criteria, there is an empty list.
             The outer list contains all groupings possible that can be made
             with the desired factors. 
    Does: While form_all_groups makes the groups of videos sharing the control
          characteristics and specifies videos by their video id, this function
          changes the video id to the number of comments the video has. Now that
          all of the videos are sorted properly, their identification no longer
          matters and duplicate comment counts are not a problem.
    '''
    groups = form_all_groups(dataset)
    for group in groups:
        for i in range(len(group)):
            for j in range(len(dataset)):
                if group[i] == dataset[j][0]:
                    group[i] = dataset[j][1]
    return groups
    

def pair_groups():
    '''
    Name: pair_groups
    Inputs: None
    Returns: A list of lists of lists. The inner-most layer of lists is the
             groupings of videos' comments, trending or control, which share
             the control factors. These lists are complied into a list with
             two elements, the list of trending videos sharing all
             controlled-for factors followed by the list of control videos
             (shown by the number of comments they have) sharing all of the
             factors that were controlled for. Then all of these length-two
             lists are compiled into a large list.
    Does: Matches up videos that share controlled-for characteristics among
          the trending and the control videos, with the groupings showing
          the number of comments each video has.
    '''

    trend_groups = change_id_to_comments(all_trending)
    control_groups = change_id_to_comments(all_control)
    all_pairs = []
    for i in range(len(trend_groups)):
        pairs = []
        pairs.append(trend_groups[i])
        pairs.append(control_groups[i])
        all_pairs.append(pairs)
    return all_pairs

def calculate_average(num_list):
    '''
    Name: calculate_average
    Inputs: num_list, a list of numbers (floats or integers)
    Returns: avg, a float representing the average of the inputted numbers
    Does: calculates the average of numbers on a list
    '''
    count = 0
    for i in range(len(num_list)):
        count += num_list[i]
    avg = count / len(num_list)
    return avg
        
    

def average_comments_per_group():
    '''
    Name: average_comments_per_group
    Inputs: nothing
    Returns: all_averages, a list of lists. The inner list has a length of two,
             where the first number represents the average comments for vidoes
             fitting into a certain grouping of controls that are trending, and
             the other represents the same calculation but for the control
             videos. Any category grouping that doesn't contain at least one
             trending and one control video is removed. All of these inner lists
             are compiled into one big list.
    Does: Finds the average number of comments for trending and control videos
          that share all control factor ranges.
    '''
    
    all_pairs = pair_groups()
    all_averages = []
    for pair in all_pairs:
        pairs = []
        for comments in pair:
            if len(comments) == 0:
                continue
            else:
                try:
                    avg = calculate_average(comments)
                    pairs.append(avg)
                except:
                    continue

        if len(pairs) == 2:
            all_averages.append(pairs)
            
    return all_averages



        
        
    
    
    


        
        

            


